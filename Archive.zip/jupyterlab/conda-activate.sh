#!/bin/bash

source /opt/conda/bin/activate base
